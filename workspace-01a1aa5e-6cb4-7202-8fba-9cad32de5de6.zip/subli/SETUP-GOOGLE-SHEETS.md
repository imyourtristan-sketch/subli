# Connect SUBLI to Google Sheets — step by step

### Step 1 — make the spreadsheet
1. Go to https://sheets.new and name it e.g. **SUBLI Ledger**.
2. Menu: **Extensions ▸ Apps Script**. A code editor opens.

### Step 2 — paste the backend
1. Delete everything in `Code.gs` in the editor.
2. Open the `Code.gs` file from this folder, copy **all** of it, paste it in.
3. Click **Save** (💾).
4. In the function dropdown at the top pick **setupSheets**, press **Run**.
5. Google asks for permission → **Review permissions ▸ choose your account ▸
   Advanced ▸ Go to project (unsafe) ▸ Allow**. (It says "unsafe" only because
   the script is unverified, not because anything is wrong.)
6. Go back to the spreadsheet: you now have **Clients**, **Payment Log**,
   **Collections** and **SyncLog** tabs with proper green headers.

### Step 3 — publish it
1. In the Apps Script editor: **Deploy ▸ New deployment**.
2. Gear icon ▸ **Web app**.
3. Description: `SUBLI v1`. **Execute as: Me**. **Who has access: Anyone**.
4. **Deploy** → copy the **Web app URL** (ends in `/exec`).

### Step 4 — tell SUBLI
1. Open the app → bottom nav **Sheets**.
2. Paste the URL in *Apps Script Web App URL* → **Sync now**.
3. Add a client, record a payment — open the Sheet and watch the rows appear.

### Troubleshooting
| Symptom | Fix |
|---|---|
| "Restore failed" | URL must end in `/exec`, and access must be **Anyone** |
| Nothing appears in the Sheet | Re-deploy: **Deploy ▸ Manage deployments ▸ ✏️ ▸ Version: New version** |
| Edited the code and nothing changed | Same as above — Apps Script serves the *deployed* version, not the saved one |
| Want to start fresh | **Deploy ▸ Manage deployments ▸ Archive**, then create a new deployment |
| Sheet columns look shifted | Re-run `setupSheets`; it repairs the header row |

### Offline behaviour
The app never blocks on the network. Every change is written to the phone first
and appended to a queue. The queue is flushed when:
* you come back online, or
* you press **Sync now**, or
* the one-minute retry timer fires.

The **Sheets** tab shows *Pending upload* and *Last successful sync*, so you
always know whether the cloud copy is current.
