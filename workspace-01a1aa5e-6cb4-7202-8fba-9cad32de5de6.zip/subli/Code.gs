/* =====================================================================
   SUBLI · Google Apps Script backend  (paste this into script.google.com)
   -------------------------------------------------------------------
   What it does
     • Creates/repairs four sheets with the exact headers you asked for.
     • Receives POSTs from the web app and upserts rows (no duplicates).
     • Serves GET ?pull=1 so a new phone can restore everything.
   Deploy:  Deploy ▸ New deployment ▸ Web app
            Execute as: Me     Who has access: Anyone
            then copy the /exec URL into SUBLI ▸ Sheets ▸ Apps Script URL.
   ===================================================================== */

/* ---------------- CONFIG ---------------- */
var SHEET_CLIENTS  = 'Clients';        // Feature 1 — loan header data
var SHEET_PAYMENTS = 'Payment Log';    // Feature 2 — per cut-off ledger
var SHEET_COLLECT  = 'Collections';    // Feature 3 — AI agent / due date table
var SHEET_LOG      = 'SyncLog';

// Feature 1 headers (exactly as requested)
var H_CLIENTS = [
  'Client ID', 'Full Name', 'Contact Number', 'Address',
  'Loan Amount', 'Interest Rate (%)', 'Months to Pay',
  'Total Interest', 'Total Loan Amount', 'Payment every Cut-off',
  'Running Balance', 'Paid To Date', 'Start Date', 'Pay Day', 'Notes',
  'Created At', 'Updated At'
];

// Feature 2 headers
var H_PAYMENTS = [
  'Payment ID', 'Client ID', 'Full Name', 'Cut-off No.',
  'DATE OF PAYMENT', 'SALARY', 'WITHDRAW', 'PAYMENT', 'CHANGE',
  'BALANCE', 'SIGNATURE', 'STATUS', 'Notes', 'Updated At'
];

// Feature 3 headers
var H_COLLECT = [
  'DUE DATE', 'NAME OF BORROWER', 'SALARY', 'WITHDRAW',
  'PAYMENT', 'CHANGE', 'SIGNATURE', 'STATUS', 'Client ID', 'Cut-off No.', 'Updated At'
];

/* ---------------- WEB ENTRY POINTS ---------------- */
function doPost(e) {
  try {
    var body = JSON.parse(e.postData.contents);
    var op = body.op, payload = body.payload || {};
    var result;
    switch (op) {
      case 'client.upsert':        result = upsertClient(payload); break;
      case 'client.delete':        result = deleteClientRow(payload.id); break;
      case 'payment.upsert':       result = upsertPayment(payload); break;
      case 'payment.bulkDelete':   result = deletePaymentsOfClient(payload.clientId); break;
      default:                     result = { ok: false, error: 'unknown op: ' + op };
    }
    writeLog(op, JSON.stringify(result));
    return json(result);
  } catch (err) {
    writeLog('error', String(err));
    return json({ ok: false, error: String(err) });
  }
}

function doGet(e) {
  // ?pull=1 returns the whole book for restoring a new device.
  if (e && e.parameter && e.parameter.pull) {
    return json({ ok: true, clients: readClients(), payments: readPayments() });
  }
  return json({ ok: true, service: 'SUBLI', time: new Date().toISOString() });
}

function json(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

/* ---------------- SHEET HELPERS ---------------- */
function book() { return SpreadsheetApp.getActiveSpreadsheet(); }

// Create a sheet with headers if missing, and repair the header row if the
// user accidentally typed over it.
function ensureSheet(name, headers) {
  var ss = book();
  var sh = ss.getSheetByName(name);
  if (!sh) sh = ss.insertSheet(name);
  var first = sh.getRange(1, 1, 1, headers.length).getValues()[0];
  var needsHeader = first.join('') !== headers.join('');
  if (needsHeader) {
    sh.getRange(1, 1, 1, headers.length).setValues([headers]);
    var hdr = sh.getRange(1, 1, 1, headers.length);
    hdr.setFontWeight('bold').setBackground('#0b7a5d').setFontColor('#ffffff');
    sh.setFrozenRows(1);
    sh.autoResizeColumns(1, Math.min(headers.length, 12));
  }
  return sh;
}
function sheets() {
  return {
    clients: ensureSheet(SHEET_CLIENTS, H_CLIENTS),
    payments: ensureSheet(SHEET_PAYMENTS, H_PAYMENTS),
    collect: ensureSheet(SHEET_COLLECT, H_COLLECT),
    log: ensureSheet(SHEET_LOG, ['When', 'Op', 'Detail'])
  };
}

// Find a row by a value in a given column. Returns 1-based row index or -1.
function findRow(sh, colIndex, value) {
  var last = sh.getLastRow();
  if (last < 2) return -1;
  var col = sh.getRange(2, colIndex, last - 1, 1).getValues();
  for (var i = 0; i < col.length; i++) {
    if (String(col[i][0]) === String(value)) return i + 2;
  }
  return -1;
}

// Feature-1 formulas, mirrored from the app so the Sheet is self-checking.
function computeLoan(row) {
  var loan = Number(row.loanAmount) || 0;
  var rate = Number(row.interestRate) || 0;
  var months = Math.max(1, Number(row.monthsToPay) || 1);
  var totalInterest = Math.round(loan * (rate / 100) * months * 100) / 100;
  var totalLoan = Math.round((loan + totalInterest) * 100) / 100;
  return {
    totalInterest: totalInterest,
    totalLoan: totalLoan,
    perCutoff: Math.round(totalLoan / months / 2 * 100) / 100
  };
}

/* ---------------- CLIENTS ---------------- */
function upsertClient(c) {
  var s = sheets();
  var sh = s.clients;
  var paid = paidTotal(c.id);
  var L = computeLoan(c);
  var row = [
    c.id, c.fullName, c.phone || '', c.address || '',
    c.loanAmount, c.interestRate, c.monthsToPay,
    L.totalInterest, L.totalLoan, L.perCutoff,
    Math.round((L.totalLoan - paid) * 100) / 100,   // running balance
    paid,
    c.startDate, c.payDay || 'both', c.notes || '',
    c.createdAt, c.updatedAt
  ];
  var at = findRow(sh, 1, c.id);
  if (at > 0) sh.getRange(at, 1, 1, row.length).setValues([row]);
  else sh.appendRow(row);
  return { ok: true, action: at > 0 ? 'updated' : 'appended' };
}

function deleteClientRow(id) {
  var s = sheets();
  var at = findRow(s.clients, 1, id);
  if (at > 0) s.clients.deleteRow(at);
  return { ok: true };
}

function readClients() {
  var s = sheets();
  var last = s.clients.getLastRow();
  if (last < 2) return [];
  return s.clients.getRange(2, 1, last - 1, H_CLIENTS.length).getValues()
    .filter(function (r) { return r[0]; })
    .map(function (r) {
      return {
        id: r[0], fullName: r[1], phone: r[2], address: r[3],
        loanAmount: Number(r[4]) || 0, interestRate: Number(r[5]) || 0,
        monthsToPay: Number(r[6]) || 1, startDate: r[12] || '',
        payDay: r[13] || 'both', notes: r[14] || '',
        createdAt: r[15] || '', updatedAt: r[16] || ''
      };
    });
}

/* ---------------- PAYMENTS (feature 2) ---------------- */
function upsertPayment(p) {
  var s = sheets();
  var name = clientName(p.clientId);
  var balance = remainingAfter(p);

  // DATE OF PAYMENT shows the actual pay date when settled, else the due date.
  var dateCol = p.paidDate || p.dueDate || '';
  var salary = Num(p.paidAmount);
  var payment = Num(p.amountDue);
  var change = Math.max(0, Math.round((salary - payment) * 100) / 100);
  var status = p.status === 'paid' ? 'PAID'
    : (p.paidAmount > 0 ? 'PARTIAL'
      : (p.dueDate < todayStr() ? 'MISSED' : 'UNPAID'));

  var row = [
    p.id, p.clientId, name, p.cutoffNo,
    dateCol, salary, salary, payment, change,
    Math.round(balance * 100) / 100,
    p.signature || '', status, p.notes || '', new Date().toISOString()
  ];

  var at = findRow(s.payments, 1, p.id);
  if (at > 0) s.payments.getRange(at, 1, 1, row.length).setValues([row]);
  else s.payments.appendRow(row);

  // Re-evaluate the client row so Running Balance stays correct.
  var c = clientObj(p.clientId);
  if (c) upsertClient(c);

  // Keep the Collections table (feature 3) in step with the same data.
  syncCollectionRow(p, name, salary, payment, change, status, balance);

  return { ok: true, action: at > 0 ? 'updated' : 'appended' };
}

// The Collections sheet is the "AI agent" output: due date, borrower,
// salary, withdraw, payment, change, signature. One row per cut-off.
function syncCollectionRow(p, name, salary, payment, change, status, balance) {
  var s = sheets();
  var sh = s.collect;
  var row = [
    p.dueDate, name, salary, salary, payment, change,
    p.signature || '', status, p.clientId, p.cutoffNo, new Date().toISOString()
  ];
  // Match on Client ID (col 9) + Cut-off No (col 10).
  var last = sh.getLastRow();
  var at = -1;
  if (last >= 2) {
    var data = sh.getRange(2, 9, last - 1, 2).getValues();
    for (var i = 0; i < data.length; i++) {
      if (String(data[i][0]) === String(p.clientId) && String(data[i][1]) === String(p.cutoffNo)) {
        at = i + 2; break;
      }
    }
  }
  if (at > 0) sh.getRange(at, 1, 1, row.length).setValues([row]);
  else sh.appendRow(row);
}

function readPayments() {
  var s = sheets();
  var last = s.payments.getLastRow();
  if (last < 2) return [];
  return s.payments.getRange(2, 1, last - 1, H_PAYMENTS.length).getValues()
    .filter(function (r) { return r[0]; })
    .map(function (r) {
      return {
        id: r[0], clientId: r[1], cutoffNo: Number(r[3]) || 0,
        dueDate: r[4] || '', paidDate: r[4] || '',
        paidAmount: Number(r[5]) || 0, amountDue: Number(r[7]) || 0,
        signature: r[10] || '', status: String(r[11] || '').toLowerCase(),
        notes: r[12] || ''
      };
    });
}

function deletePaymentsOfClient(clientId) {
  var s = sheets();
  var sh = s.payments;
  var last = sh.getLastRow();
  for (var r = last; r >= 2; r--) {
    if (String(sh.getRange(r, 2).getValue()) === String(clientId)) sh.deleteRow(r);
  }
  var sh2 = s.collect;
  var last2 = sh2.getLastRow();
  for (var r2 = last2; r2 >= 2; r2--) {
    if (String(sh2.getRange(r2, 9).getValue()) === String(clientId)) sh2.deleteRow(r2);
  }
  return { ok: true };
}

/* ---------------- SMALL UTILS ---------------- */
function Num(v) { var n = Number(v); return isFinite(n) ? n : 0; }
function todayStr() {
  return Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd');
}

function clientObj(id) {
  var list = readClients();
  for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
  return null;
}
function clientName(id) {
  var c = clientObj(id);
  return c ? c.fullName : '(deleted client)';
}
function paidTotal(clientId) {
  var ps = readPayments();
  var t = 0;
  for (var i = 0; i < ps.length; i++) if (ps[i].clientId === clientId) t += ps[i].paidAmount;
  return Math.round(t * 100) / 100;
}
function remainingAfter(p) {
  var c = clientObj(p.clientId);
  if (!c) return 0;
  var L = computeLoan(c);
  return Math.max(0, L.totalLoan - paidTotal(p.clientId));
}
function writeLog(op, detail) {
  try {
    var s = sheets();
    s.log.appendRow([new Date(), op, String(detail).slice(0, 480)]);
  } catch (e) { /* logging must never break the sync */ }
}

/* ---------------- ONE-TIME SETUP ---------------- */
// Run this once from the editor to create all sheets + headers.
function setupSheets() {
  var s = sheets();
  var ss = book();
  // Drop the default empty "Sheet1" if it is still there.
  var junk = ss.getSheetByName('Sheet1');
  if (junk && ss.getSheets().length > 1 && junk.getLastRow() === 0) ss.deleteSheet(junk);
  SpreadsheetApp.getUi && SpreadsheetApp.getUi().alert(
    'SUBLI is ready.\n\nSheets created: ' + [SHEET_CLIENTS, SHEET_PAYMENTS, SHEET_COLLECT, SHEET_LOG].join(', ')
  );
}

// Optional: build a "Due Today" filtered view inside the sheet.
function buildDueTodayFilter() {
  var s = sheets();
  var sh = s.collect;
  var last = sh.getLastRow();
  if (last < 2) return;
  var values = sh.getRange(2, 1, last - 1, H_COLLECT.length).getValues();
  var out = [H_COLLECT];
  var today = todayStr();
  values.forEach(function (r) {
    var st = String(r[7] || '').toUpperCase();
    var due = r[0] instanceof Date
      ? Utilities.formatDate(r[0], Session.getScriptTimeZone(), 'yyyy-MM-dd')
      : String(r[0]).slice(0, 10);
    if (due <= today && st !== 'PAID') out.push(r);
  });
  var view = book().getSheetByName('Due Today') || book().insertSheet('Due Today');
  view.clear();
  view.getRange(1, 1, out.length, H_COLLECT.length).setValues(out);
  view.getRange(1, 1, 1, H_COLLECT.length).setFontWeight('bold').setBackground('#b07d10').setFontColor('#fff');
  view.setFrozenRows(1);
}
