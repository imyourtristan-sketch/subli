# SUBLI — Lending Ledger Web App

An offline-first lending ledger for a "5-6" / subli style money-lending business.
Single page, no build step, no framework. Works on a phone browser and installs
to the home screen.

| File | What it is |
|---|---|
| `index.html` | The whole app — UI, styles and logic (commented section by section) |
| `Code.gs` | Google Apps Script backend that creates and feeds your Google Sheet |
| `manifest.webmanifest` | Makes it installable ("Add to Home Screen") |
| `sw.js` | Service worker — lets the app open with zero signal |
| `icon.svg` | App icon |

---

## 1. Run it right now

Open `index.html` in any browser (or the live preview). Tap **More ▸ Load demo data**
to see three borrowers with history.

---

## 2. Google Sheets setup (5 minutes, one time)

1. Create a Google Sheet → **Extensions ▸ Apps Script**.
2. Delete the placeholder code, paste the whole of **`Code.gs`**.
3. **Run ▸ `setupSheets`** and accept the permission prompt.
   Four tabs appear with your exact column headers:

   **`Clients`** (feature 1)
   `Client ID · Full Name · Contact Number · Address · Loan Amount ·
   Interest Rate (%) · Months to Pay · Total Interest · Total Loan Amount ·
   Payment every Cut-off · Running Balance · Paid To Date · Start Date ·
   Pay Day · Notes · Created At · Updated At`

   **`Payment Log`** (feature 2)
   `Payment ID · Client ID · Full Name · Cut-off No. · DATE OF PAYMENT ·
   SALARY · WITHDRAW · PAYMENT · CHANGE · BALANCE · SIGNATURE · STATUS · Notes · Updated At`

   **`Collections`** (feature 3 — the AI agent's table)
   `DUE DATE · NAME OF BORROWER · SALARY · WITHDRAW · PAYMENT · CHANGE ·
   SIGNATURE · STATUS · Client ID · Cut-off No. · Updated At`

   *Optional:* run `buildDueTodayFilter` to get a live **Due Today** tab.

4. **Deploy ▸ New deployment ▸ Web app**
   * Execute as: **Me**
   * Who has access: **Anyone**
   Copy the `…/exec` URL.
5. In SUBLI: **Sheets ▸ Apps Script Web App URL** → paste → **Sync now**.

Once that URL is saved, every client, payment and signature you enter is
pushed to the Sheet. No internet? The change is queued in the app and
uploaded automatically the moment you reconnect (and retried every minute).

---

## 3. How each requested feature is implemented

**1 · Loan header + form.** The "New client" form (bottom `+` button) captures
full name, loan amount, editable interest rate and editable months to pay.
The four formulas are shown live while you type:

```
Total Interest   = Loan Amount × (Interest Rate ÷ 100) × Months
Total Loan       = Loan Amount + Total Interest
Per cut-off      = Total Loan ÷ Months ÷ 2        (15th and 30th)
Running Balance  = Total Loan − Σ payments
```

**2 · Payment ledger.** Tapping a client opens their ledger with the columns
*Date of Payment · Salary · Withdraw · Payment · Change · Balance · Signature*.
Rows are generated from the number of months automatically. Tap any row to
record a payment, type the amount, and sign with a finger/mouse — the signature
is stored with that row (and as a column in the Sheet). Balance recalculates instantly.

**3 · Due-date AI agent.** The **Due** tab runs an analysis over every schedule:
who is due *today*, who is **overdue**, and who is coming in 3 days, with totals
and priority names. Recording a payment there updates the client's paid status
everywhere. Reminders:
* **🔔 Reminders** → browser notification at each cut-off; tapping it opens
  this app on the Due screen.
* **📅 Add to Calendar** → downloads `SUBLI-collections.ics`, one event per
  unpaid cut-off with a 9 AM alarm. Import it once and your phone calendar
  notifies you on every due date.
* **🌐 Google Cal** → one-click Google Calendar event for today's batch.

**4 · Home.** Exactly six data points per client — name, number, address,
loan amount, total interest, remaining balance. Tap a card → their ledger (feature 1).

**5 · Comments.** Every function and section in `index.html` and `Code.gs` is commented.

Plus: full **CRUD** (create / read / update / delete on clients and payments),
**fluid mobile UI**, **bottom icon navigation**, **printable receipts**
(single cut-off / a month / only paid / full statement, with the client's
signature and a PDF option), and **offline queue** with automatic sync.

---

## 4. Hosting options

**Free & instant**
* **Netlify Drop** — drag the `subli` folder onto https://app.netlify.com/drop. Live in seconds, free HTTPS.
* **Vercel** — `npx vercel` inside the folder.
* **GitHub Pages** — push the folder, Settings ▸ Pages ▸ main branch. `https://you.github.io/subli/`
* **Cloudflare Pages** — connect the repo, no build command, output dir `/`.

HTTPS matters: notifications, the service worker and "Add to Home Screen"
need it (localhost is exempt).

**Your own hosting** — any static host works (cPanel `public_html`, Hostinger,
Namecheap, Synology). Upload the five files, done. No PHP, no database, no Node.

**Turn it into a phone app (optional)**
The PWA already installs from the browser. For an APK, wrap it:
* **PWABuilder** (https://pwabuilder.com) → paste your URL → download an Android
  package, or
* **Capacitor**: `npm i @capacitor/core @capacitor/cli && npx cap add android`.

**Data safety** — the ledger lives in the phone's localStorage, so:
1. Keep the Google Sheet connected (that is your cloud backup).
2. Use **Sheets ▸ Export JSON** weekly.
3. Use **Restore from Sheet** when switching phones or clearing browser data.

---

## 5. Good next features (pick any and I'll build them)

1. **Collector / field-agent accounts** with a shared Sheet and per-agent filter.
2. **Penalty & late fees** — auto late charge %, grace period, restructured balance.
3. **Partial-payment carry-over** — unpaid remainder rolls into the next cut-off automatically.
4. **SMS / Viber / WhatsApp reminder** — one-tap prefilled message with amount due.
5. **Loan restructure / top-up** — add a second release to an existing client with one combined balance.
6. **Dashboard analytics** — collections this month, interest earned, aging report (30/60/90), collection rate.
7. **Client portal** — read-only link where a borrower sees their own balance.
8. **Multi-currency + rounding rules** (e.g. round to nearest ₱5).
9. **Photo collateral** — attach a picture of an ID or item as security.
10. **True native reminders** — Firebase push + a service worker so reminders arrive
    even when the app is closed (needs a small backend or Firebase project).
11. **Excel/PDF export** of the whole book, and a **daily collection sheet** for printing.
12. **Roles + audit log** — who recorded which payment and when.
